# 🚀 GitHub 部署指南

## 步驟 1: 創建 GitHub Repository

1. 前往 https://github.com/new
2. Repository name: `stock-trading-suite`
3. 選擇 "Public"
4. 點擊 "Create repository"

## 步驟 2: 上傳檔案

### 方法 A: 網頁上傳 (推薦)
1. 在新創建的 repo 頁面，點擊 "uploading an existing file"
2. 將 `stock-trading-suite.zip` 解壓縮
3. 上傳所有檔案

### 方法 B: 命令行
```bash
cd stock-trading-suite
git remote add origin https://github.com/tc-gh-claw/stock-trading-suite.git
git branch -M main
git push -u origin main
```

## 步驟 3: 開啟 GitHub Pages

1. 進入 repository → Settings → Pages
2. Source: 選擇 "Deploy from a branch"
3. Branch: 選擇 "main" → "/ (root)"
4. 點擊 "Save"
5. 等待 2-3 分鐘
6. 網址會顯示在 Pages 設定頁面

## 步驟 4: 手機安裝

### iPhone (Safari)
1. 用 Safari 開啟網站
2. 點擊分享按鈕 (底部分享圖標)
3. 選擇「加入主畫面」
4. 完成！App 圖標出現在手機桌面

### Android (Chrome)
1. 用 Chrome 開啟網站
2. 點擊選單 (右上角三點)
3. 選擇「安裝應用程式」或「新增至主畫面」
4. 完成！

## 📱 PWA 功能

安裝後享有：
- ✅ 全螢幕模式 (無瀏覽器地址欄)
- ✅ 離線使用
- ✅ 像原生 App 的體驗
- ✅ 自動更新

## 🔗 預期網址

部署完成後網址：
```
https://tc-gh-claw.github.io/stock-trading-suite/
```

## ⚠️ 注意事項

1. 圖標檔案 (icon-*.png) 暫時使用預設，可後續替換
2. 如要自訂圖標，可使用 https://www.pwabuilder.com/imageGenerator
3. 數據儲存在手機本地，清除瀏覽器數據會重置

## 🎉 完成！

部署完成後，你就有一個可以：
- 📱 手機安裝的 App
- 🔗 外連分享的網址
- 🌐 離線使用的 PWA

---

開發者：蝦仔 🦐
