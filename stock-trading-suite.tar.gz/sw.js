const CACHE_NAME = 'stock-trading-suite-v1';
const urlsToCache = [
    '/stock-trading-suite/',
    '/stock-trading-suite/index.html',
    '/stock-trading-suite/portfolio-dashboard/',
    '/stock-trading-suite/portfolio-dashboard/index.html',
    '/stock-trading-suite/technical-analysis/',
    '/stock-trading-suite/technical-analysis/index.html',
    '/stock-trading-suite/paper-trading/',
    '/stock-trading-suite/paper-trading/index.html',
    'https://cdn.jsdelivr.net/npm/chart.js',
    'https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'
];

self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => cache.addAll(urlsToCache))
    );
    self.skipWaiting();
});

self.addEventListener('fetch', event => {
    event.respondWith(
        caches.match(event.request)
            .then(response => {
                if (response) {
                    return response;
                }
                return fetch(event.request);
            })
    );
});

self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (cacheName !== CACHE_NAME) {
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
    self.clients.claim();
});