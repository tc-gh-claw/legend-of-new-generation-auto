# 股票交易應用套件 | Stock Trading Suite

專為香港投資者設計的專業級股票工具，支援手機、平板、電腦全平台使用。

## 🚀 三款應用

### 1. 📊 投資組合 Dashboard
追蹤你的投資組合，實時監控損益、資產配置。

**功能特色：**
- 多股票持倉管理
- 實時損益計算
- 資產配置圓餅圖
- 價格走勢圖表
- LocalStorage 數據儲存

### 2. 📈 技術分析工具
專業級K線圖表，支援多種技術指標。

**功能特色：**
- K線圖表 (Candlestick)
- 技術指標：MA、RSI、MACD、布林通道
- 多時間框架 (1分鐘至月線)
- 買賣信號提示
- 自選股票列表

### 3. 🪙 模擬交易平台
零風險練習股票交易，提供 HK$100,000 模擬資金。

**功能特色：**
- HK$100,000 模擬資金
- 真實市場價格模擬
- 完整交易紀錄
- 排行榜系統
- 手機優化界面

## 📱 使用方式

### 線上使用
訪問：[https://tc-gh-claw.github.io/stock-trading-suite/](https://tc-gh-claw.github.io/stock-trading-suite/)

### 本地使用
```bash
git clone https://github.com/tc-gh-claw/stock-trading-suite.git
cd stock-trading-suite
# 直接打開 index.html 即可使用
```

## 🛠️ 技術棧

- HTML5 + CSS3 + Vanilla JavaScript
- Chart.js - 圖表庫
- Lightweight Charts - K線圖表
- LocalStorage - 數據持久化

## 📋 系統需求

- 現代瀏覽器 (Chrome, Firefox, Safari, Edge)
- 支援手機、平板、電腦
- 無需安裝，純前端運行

## ⚠️ 免責聲明

本應用套件僅供學習和模擬交易用途，不構成任何投資建議。
股票市場有風險，投資需謹慎。

## 📝 開發者

開發者：蝦仔 (Shrimp Boy) 🦐

---

**最後更新：** 2026-03-02
